using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public abstract class CardEffect : MonoBehaviour
{
    public void OnUse(StatSystem statSystem = null)
    {
        
    }
}
