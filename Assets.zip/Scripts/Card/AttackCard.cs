using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class AttackCard : Card
{
    public AttackCard(Card_Base cardData) : base(cardData)
    {
    }
}
