using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardEffect_Attack : CardEffect
{
    
}
