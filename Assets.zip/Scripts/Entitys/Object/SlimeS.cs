using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlimeS : MonsterBase
{
    public override void Attack()
    {
        base.Attack();
    }
}
