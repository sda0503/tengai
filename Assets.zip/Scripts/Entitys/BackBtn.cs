﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackBtn : MonoBehaviour
{
    private void OnMouseEnter() 
    { 
        print("마우스가 오브젝트 위에 있습니다."); 
    }
}
