using System.Collections;
using System.Collections.Generic;
using UnityEngine;



[CreateAssetMenu(fileName = "Relics", menuName = "New Relics")]

public class RelicsData : ScriptableObject
{
    [Header("Info")]
    public string RelcisName;
    public string Relcisdescription;
    public Sprite icon;

}
