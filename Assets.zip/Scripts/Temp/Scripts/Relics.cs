using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Relics : MonoBehaviour
{
    public string relicsName;
    public StatSystem _stat;

    public bool isIronclad; // 캐릭터가 아이언클래드인지
    public bool isFighting; // 전투 중인지
    public bool isElite; // 상대가 엘리트인지
    public bool isBoss; // 상대가 보스인지

}
